#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void ignore_me_init_buffering() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void kill_on_timeout(int sig) {
    if (sig == SIGALRM) {
        printf("[!] Anti DoS Signal. Patch me out for testing.");
        exit(0);
    }
}

void ignore_me_init_signal() {
    signal(SIGALRM, kill_on_timeout);
    alarm(60);
}

int validate_input(const char *input) {
    const char *red_flash = "\033[5;31m";
    const char *reset = "\033[0m";
    
    if (!isdigit(input[0]) || input[1] != '\n' && input[1] != '\0') {
        printf("Invalid input detected!\n");
        printf("Input log: %s", reset);
        printf("%s", red_flash);
        printf(input);
        printf("%s", reset);
        return 0; 
    }
    return 1;
}

int main() {

    const char *cyan1 = "\033[1;36m";
    const char *cyan2 = "\033[0;36m";
    const char *cyan3 = "\033[38;5;49m"; 
    const char *cyan4 = "\033[38;5;50m"; 
    const char *cyan5 = "\033[38;5;51m"; 
    const char *cyan6 = "\033[38;5;44m"; 
    const char *cyan7 = "\033[38;5;36m"; 
    const char *cyan8 = "\033[38;5;30m"; 
    const char *reset = "\033[0m";

    ignore_me_init_buffering();
    ignore_me_init_signal();

    printf("%s ██▓ ██▀███   ▒█████   ███▄    █  ▄████▄   ██▓    ▄▄▄      ▓█████▄ \n", cyan1);
    printf("%s▓██▒▓██ ▒ ██▒▒██▒  ██▒ ██ ▀█   █ ▒██▀ ▀█  ▓██▒   ▒████▄    ▒██▀ ██▌\n", cyan2);
    printf("%s▒██▒▓██ ░▄█ ▒▒██░  ██▒▓██  ▀█ ██▒▒▓█    ▄ ▒██░   ▒██  ▀█▄  ░██   █▌\n", cyan3);
    printf("%s░██░▒██▀▀█▄  ▒██   ██░▓██▒  ▐▌██▒▒▓▓▄ ▄██▒▒██░   ░██▄▄▄▄██ ░▓█▄   ▌\n", cyan4);
    printf("%s░██░░██▓ ▒██▒░ ████▓▒░▒██░   ▓██░▒ ▓███▀ ░░██████▒▓█   ▓██▒░▒████▓ \n", cyan5);
    printf("%s░▓  ░ ▒▓ ░▒▓░░ ▒░▒░▒░ ░ ▒░   ▒ ▒ ░ ░▒ ▒  ░░ ▒░▓  ░▒▒   ▓▒█░ ▒▒▓  ▒ \n", cyan6);
    printf("%s ▒ ░  ░▒ ░ ▒░  ░ ▒ ▒░ ░ ░░   ░ ▒░  ░  ▒   ░ ░ ▒  ░ ▒   ▒▒ ░ ░ ▒  ▒ \n", cyan7);
    printf("%s ▒ ░  ░░   ░ ░ ░ ░ ▒     ░   ░ ░ ░          ░ ░    ░   ▒    ░ ░  ░ \n", cyan8);
    printf("%s ░     ░         ░ ░           ░ ░ ░          ░  ░     ░  ░   ░    \n", cyan8);
    printf("%s                                 ░                          ░      \n", cyan8);

    printf("%s", reset);

    char input1[0xB0], input2[0xB0];

    const char *red_flash = "\033[5;31m";
    printf("\nDigit Checker (Odd or Even)\n\n");
    printf("Enter first number (0-9): ");
    fgets(input1, 0xB0, stdin);
    validate_input(input1);
    printf("Enter second number (0-9): ");
    fgets(input2, 0xF0, stdin);
    validate_input(input2);

    if (isdigit(input1[0]) && (input1[1] == '\n' || input1[1] == '\0') &&
        isdigit(input2[0]) && (input2[1] == '\n' || input2[1] == '\0')) {
        int num1 = input1[0] - '0';
        int num2 = input2[0] - '0';

        int sum = num1 + num2;
        printf("Sum: %d - This number is ", sum);
        if (sum % 2 == 0) {
            printf("%sEven%s\n", cyan6, reset);
        } else {
            printf("%sOdd%s\n", cyan6, reset);
        }
    } 

    return 0;
}
