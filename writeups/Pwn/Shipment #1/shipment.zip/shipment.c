#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <capstone/capstone.h>

#define SHELLCODE_SIZE 0x10
#define RANDOM_BYTES_SIZE 0x1000

void setup() {
    setbuf(stdout, NULL);
    setbuf(stdin, NULL);
    setbuf(stderr, NULL);
}

char* get_important_data() {
    char *data = (char *)malloc(RANDOM_BYTES_SIZE);
    FILE *stream = fopen("/dev/random", "r");
    if (!stream) {
        puts("[!] Error opening /dev/random");
        free(data);
        exit(1);
    }

    fread(data, 1, RANDOM_BYTES_SIZE, stream);
    fclose(stream);
    return data;
}

void print_flag() {
    char flag[100];
    FILE *stream = fopen("./flag.txt", "r");
    if (!stream) {
        puts("[!] Error opening the flag file");
        exit(1);
    }

    fgets(flag, sizeof(flag), stream);
    printf("[+] %s", flag);
    fclose(stream);
}

int check_shellcode(char *shellcode, size_t size) {
    csh handle;
    cs_insn *insn;
    size_t count;
    int result = 1;

    if (cs_open(CS_ARCH_X86, CS_MODE_64, &handle) != CS_ERR_OK) {
        puts("[!] Could not initialize Capstone");
        return -1;
    }

    count = cs_disasm(handle, (unsigned char *)shellcode, size, (uintptr_t)shellcode, 0, &insn);
    if (count > 0) {
        printf("[-] Disassembled shellcode:\n");
        for (size_t j = 0; j < count; j++) {
            printf("[*] 0x%" PRIx64 ":  ", insn[j].address);
            unsigned char *byte_ptr = (unsigned char *)&shellcode[insn[j].address - (uintptr_t)shellcode];
            for (size_t k = 0; k < insn[j].size; k++) {
                printf("%02x ", byte_ptr[k]);
            }

            for (size_t k = insn[j].size; k < 7; k++) {
                printf("   ");
            }

            printf("%s\t%s\n", insn[j].mnemonic, insn[j].op_str);
        }
    } else {
        puts("[!] Invalid shellcode");
        result = 0;
    }

    cs_free(insn, count);
    cs_close(&handle);

    return result;
}

int main() {

    setup();

    puts("[-] Hello there! I have some important bytes that I need moved. Can you help me?");

    char target_location[RANDOM_BYTES_SIZE];
    char *random_bytes;

    // Allocate and read random data
    random_bytes = get_important_data();

    // Allocate shellcode memory
    char *shellcode = mmap(NULL, SHELLCODE_SIZE, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_ANON, 0, 0);
    
    // Read in shellcode
    puts("[i] Enter your shellcode:");
    ssize_t bytes_read = read(0, shellcode, SHELLCODE_SIZE);

    // Check shellcode
    if (check_shellcode(shellcode, bytes_read) != 1) {
        free(random_bytes);
        return 1;
    }

    puts("[+] Shellcode seems valid");
    puts("[-] Executing...");

    // Execute shellcode with arguments >:)
    ((void (*)())shellcode)(target_location, random_bytes);

    // Compare memory
    puts("[-] Checking...");
    if (memcmp(target_location, random_bytes, RANDOM_BYTES_SIZE) == 0) {
        puts("[+] They are identical! Thank you so much. Have a flag on me:");
        print_flag();
    } else {
        puts("[!] Nope");
    }

    munmap(shellcode, SHELLCODE_SIZE);
    free(random_bytes);
    return 0;
}