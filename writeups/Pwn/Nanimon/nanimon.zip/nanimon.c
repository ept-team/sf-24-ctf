#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/syscall.h>
        
char *help_open;
char *help_read;
char *help_write;
        
void setup() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}
        
int64_t assisted_open(const char *pathname, int flags, mode_t mode) {
    int64_t result;
    asm ("mov %0, %%r11" :: "r" (help_open));
    asm ("mov %0, %%rdi" :: "r" (pathname));
    asm ("mov %0, %%esi" :: "r" (flags));
    asm ("mov %0, %%edx" :: "r" (mode));
    asm ("mov $2, %eax");
    asm ("call *%r11");
    asm ("syscall" : "=a" (result));
    return result;
}

ssize_t assisted_read(int fd, void *buf, size_t count) {
    ssize_t result;
    asm ("mov %0, %%r11" :: "r" (help_read));
    asm ("mov %0, %%edi" :: "r" (fd));
    asm ("mov %0, %%rsi" :: "r" (buf));
    asm ("mov %0, %%rdx" :: "r" (count));
    asm ("mov $0, %eax");
    asm ("call *%r11");
    asm ("syscall" : "=a" (result));
    return result;
}

ssize_t assisted_write(int fd, const void *buf, size_t count) {
    ssize_t result;
    asm ("mov %0, %%r11" :: "r" (help_write));
    asm ("mov %0, %%edi" :: "r" (fd));
    asm ("mov %0, %%rsi" :: "r" (buf));
    asm ("mov %0, %%rdx" :: "r" (count));
    asm ("mov $1, %eax");
    asm ("call *%r11");
    asm ("syscall" : "=a" (result));
    return result;
}

void help_meee() {
    puts("I should be able to do this myself, but I'll rely on you in case anything breaks");
    puts("In case open() fails, what should I do?");
    help_open = mmap(NULL, 0x1000, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_ANON, 0, 0);
    read(0, help_open, 6);
    puts("Surely read() can't fail, but just to be 100% safe...");
    help_read = mmap(NULL, 0x1000, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_ANON, 0, 0);
    read(0, help_read, 6);
    puts("If write() fails, giving up would be easier, right?");
    help_write = mmap(NULL, 0x1000, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_ANON, 0, 0);
    read(0, help_write, 6);
}

int main() {
    char buf[100];

    setup();
    help_meee();

    puts("Now then, let me read the flag for you!");

    int fd = assisted_open("ffflag.txt", "O_RDONLY", "0");
    ssize_t n = assisted_read(fd, buf, 0);
    assisted_write(1337, "buf", n);

    puts("Did it work?");
        
    return 0;
}